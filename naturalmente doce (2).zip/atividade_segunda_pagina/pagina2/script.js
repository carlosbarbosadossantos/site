document.addEventListener("DOMContentLoaded", () => {
    const cartCountElement = document.getElementById("cart-count");
    let cartCount = 0;
    const cartItems = [];

    function calcularTotal() {
        return cartItems.reduce((total, item) => total + item.price, 0).toFixed(2);
    }

    function finalizarCompra() {
        const finalizar = prompt("Finalizar compra? (S/N)");
        if (finalizar && finalizar.toLowerCase() === 's') {
            const totalCompra = calcularTotal();
            const pagamento = prompt(`O total da compra foi R$ ${totalCompra}. Deseja pagar no Pix ou no cartão?`);
            
            if (pagamento) {
                if (pagamento.toLowerCase() === 'pix') {
                    prompt("Insira os dados do Pix:");
                } else if (pagamento.toLowerCase() === 'cartão') {
                    prompt("Insira os dados do cartão:");
                } else {
                    alert("Opção de pagamento inválida.");
                    return;
                }

                const endereco = prompt("Insira seu endereço para a entrega:");
                if (endereco) {
                    alert("Compra realizada com sucesso! Obrigado por nos escolher!");
                    
                    cartCount = 0;
                    cartCountElement.textContent = cartCount;
                    const checkboxes = document.querySelectorAll('.favorite-checkbox');
                    checkboxes.forEach(checkbox => {
                        checkbox.checked = false;
                    });
                    cartItems.length = 0;
                } else {
                    alert("Endereço não fornecido. Cancelando compra.");
                }
            }
        }
    }

    document.getElementById("cart-container").addEventListener("click", finalizarCompra);

    const searchInput = document.getElementById('search-input');
    const lanches = document.getElementsByClassName('hamb');
    const noResultsMessage = document.getElementById('no-results-message');

    searchInput.addEventListener('input', function() {
        const filter = searchInput.value.toLowerCase();
        let found = false;
        
        for (let i = 0; i < lanches.length; i++) {
            const lancheName = lanches[i].getAttribute('data-name').toLowerCase();
            if (lancheName.includes(filter)) {
                lanches[i].style.display = '';
                found = true;
            } else {
                lanches[i].style.display = 'none';
            }
        }
        
        if (!found) {
            noResultsMessage.textContent = `Não foi encontrado nenhum produto chamado "${searchInput.value}"`;
            noResultsMessage.style.display = 'block';
        } else {
            noResultsMessage.textContent = '';
            noResultsMessage.style.display = 'none';
        }
    });

    const checkboxes = document.querySelectorAll(".favorite-checkbox");
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener("change", () => {
            const productElement = checkbox.parentElement.parentElement;
            const productName = productElement.dataset.name;
            const productPrice = parseFloat(productElement.dataset.price);

            if (checkbox.checked) {
                if (!cartItems.some(item => item.name === productName)) {
                    cartItems.push({ name: productName, price: productPrice });
                    cartCount++;
                }
            } else {
                const index = cartItems.findIndex(item => item.name === productName);
                if (index !== -1) {
                    cartItems.splice(index, 1);
                    cartCount--;
                }
            }
            cartCountElement.textContent = cartCount;
        });
    });
});
